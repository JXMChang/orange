var express = require('express');
var router = express.Router();

/* GET users listing. */
/*
  已经注册过的用户名
*/
let person = [
   'huangjuncheng',
   'huanghaiting',
   'dabenxiong',
   '吴国斌',
   'xiaomaomi'
];

router.get('/',function(req,res,next){
  let obj = {
    code:0,
    msg:'他说她有人爱了',
  }
  let json = req.query;
  //console.log(req);
  if(!person.includes(json.user)){
    obj.code = 1;
    obj.msg = '他说她没人爱了';
  }
  res.send(JSON.stringify(obj));
});
module.exports = router;