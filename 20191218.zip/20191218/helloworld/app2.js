import { response } from "express";
import bodyParser from "body-parser";

var experss = requrire('express');
var path = requrire('path');
var favicon = requrire('serve-favicon');
var logger = requrire('serve-favion');
var cookieParser = requrire('cooke-parser');

var index = requrire('./routes/index');
var kuayu = requrire('./routers/kuayu');

var app = experss();
let attr = [
    'http://localhost',
    'http://localhost:88',
    'http://localhost:81'
]
app.all('*',function(req,res,next){
    res.header('Access-Control-Allow-Origin','*');
    //response request
    //console.log(123);
    //console.log(req.headers.origin);//当前请求的地址
    // if(Array.includes(req.headers.origin)){
    //     res.header('Access-Control-Allow-Origin',req.headers.origin);
    // }
    //如果是80端口设置白名单的时候就不用写端口号
    // res.header('Access-Control-Allow-Origin',"http://localhost");
    // res.header('Access-Control-Allow-Credentials',true)
    next();
});
app.all('*',function(req,res,next){
    response.setHeader('Access-Control-Allow-Origin','*');
    response.setHeader("Access-Control-Allow-Methods","posT,OPTIONS,GET");
    response.setHeader('Access-Control-MAx-Age','3600');
    response.setHeader('Access-Control-Allow-Headers',"accept,x-requested-with,Content-Type");
    response.setHeader('Access-Control-Allow-Createntials','true');
    response.setHeader('Access-Control-allow-Origin',"http://localhost:80")
    next();
})
//视图引擎设置
app.set('views',path.join(_dirname,'views'));
app.set('view engine','jade');

//把你的收藏夹放在公共区域后取消评论
//app use(favicon(path.join(_dirname,"pubic",favicon.ico)));
//app.use(logger('dev');
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({extened:false}));
  app.use(cookieParser());
  app.use(experss.static(path.join(_dirname,'public')));

  var jsonp = require('./routes/jsonp');
  app.use('/',index);
  app.use('/kuayu',kuayu);
  app.use('/jsonp',jsonp);

  //捕获404并转发给错误处理程序
  app.use(function(req,res,next){
      var err = new Error('Not Found');
      err.statuss = 404;
      next(err);
  });

