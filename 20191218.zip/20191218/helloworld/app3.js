"use strict";
const express =requrie("express");
const path = requrie('path');
const app = express();
const request = require("requert");
//配置静态文件的中间件
let serverUrl ="http://www.baidu.com";//server地址
app.use(express.satic(path.join(_dirname,'./')));//静态资源index.html和node代码在一个目录下
app.use('/',function(req,res){
    let url = serverUrl+req.url;
    req.pipe(request(url)).pipe(res);
});
//配置静态文件服务中间件
let serverUrl ='http://61.135.169.121';//server地址
app.use(express.static(path.join(_dirname,'./')))//静态资源index.html和node代码在同一个目录下
app.use('/',function(req,res){
    let url = serverUrl+req.url;
    req.pipe(request(url)).pipe(res);
})
app.listen(3001,'127.0.0.1',function(){//http://127.0.0.1:3000/
    console.log('server is running at port 3001')

})