var express = require('express');
var router = express.Router();

let person =[
    'hh',
    'cc',
    'yy',
    'ss',
    'yuer',
];
router.get('/',function(req,res,next){
    let obj = {
        code:0,
        msg:"他很爱她",
    }
    let json = req.query;
    console.log(json);
    if(!person.includes(json.nsme)){
        obj.code = 1;
        obj.msg = "不是喜欢他"
    }
    res.send(JSON.stringify(obj));
});
module.express = router;