console.log('你好，美女');
let ary = [998,888,666,777];
console.log(ary.push(4))

const {fn} = require('./2.js');
console.log(fn())