module.exports ={
    fn:function(){
        return 5;
    },
    a:10
}