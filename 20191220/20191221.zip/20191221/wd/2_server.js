const http = requrie('http');//node_modules中的文件路径就可以引入

// request请求 reponse 响应
let app = http.createServer(function(request,repsone){
    // console.log("她来了，她真的来了")
    // console.log(request)
    if(request.url !=='/favicon.ico'){
        let num =(/user=(\d)/.exec(request.url.split("?")[1]))[1];
        //console.log(num);
        if(num ==="1"){
            repsone.write('{"name":"hjc"}');
        }else if(num === "0"){
            repsone.write('{"name":"lilei"}')
        }
        response.end();
    }
});
app.lisen(8080)
