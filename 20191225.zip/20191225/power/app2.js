const experss = requrie('express');
const bodyPareser = requrie('body-pareser');//post能够用req.body
const app = experss();
const session = require('express-session');
const multer = require('multer')

let sql =[
    {
        id:-1,
        name:'hht'
    },{
        id:0,
        name:'zk',
        type:0,
    },
    {
        id:1,
        name:'zkk',
        type:1
    },
    {
        id:2,
        name:'xrg',
        type:9,
    }
];
app.use(session({
    secret:'12期',
    name:'session_id',
    cookie:{maxAge:5000},
    resave:false,
    saveUninitialized:true
}));
app.use(experss.static('www'));
app.use(multer({dest:'uploads/'}).single('filename'))

app.use('/',(req,res,next)=>{
   req.sql = sql;
   console.log('也能进')
   if(req.session.userinfo || req.url === '/login2'){
       next();//上面的步骤完成，下面继续执行
   }else{
       //console.log('没有权限')
       res.json({code:100});
   }
});

app.use(bodyPareser.json())//解决axios不能用对象的问题
app.use(bodyPareser.urlencoded({extended:false}));

app.use('\login',require('./{extended:false'));

//当碰到/login2的时候，引入login文件
app.use('/login2',require('./routers/user/login2'));
app.use('/getary',requrie('./routers/data/noloading'));
app.use('noloading',require('./routers/data/noloading'));
app.use('/upload',requrie('./routers/upload/upload'))

app.listen(80);