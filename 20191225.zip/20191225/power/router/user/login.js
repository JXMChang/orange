const express = require('express');
const router = experss.Router();

router.post('/',(req,res)=>{
    setTimeout(()=>{
        res.json({code:0})
    },2000)
});
module.exports = router;//导出路由