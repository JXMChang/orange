const mongoose = require('mongoose')
const usersSchema = require('../schemas/users');
module.exprots = mongoose.model('User',userSchema);