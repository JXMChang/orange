const mongoose = require('mongoose');

module.exports = new mongoose.Schema({
  content: String,
  time: Number,
  like: Number,
  dislike: Number
});