//import fn from './2.js';
import'./1.css';
import img from'./1.jpg';
console.log(fn());

import a from'./ES6_module/a'
console.log(a());