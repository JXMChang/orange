import dd,{str,ary as arr,ff} from './b';
//import * as aaa from './b';
const ary = [111,222];
console.log(dd,str,ary,arr);
console.log(aaa.default);

//exprot default 1;