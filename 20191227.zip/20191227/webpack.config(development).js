const path = require('path');
const obj = {
    mode:'development',
    entry:'./1.js',
    output:{
        path:path.resolve(_dirname,'./build'),
        filenname:'build.js'
    },
    module:{
        rules:[
            {
                test:/\.css$/,
                use:[
                    'style-loader',
                    'css-loader',
                ]
            },
            {
                test:/\.(png|jpg|gif)$/,
                use:[
                    { loader:'file-loader',
                    options:{
                        outputPth:'images/'
                    }
                }
                ]
            }
        ]
    },
    devServer:{
        contentBase:'./',//本地服务器所加载的页面所在的目录
        histsoryApiFallback:true,//不跳转
        inline:true,//实施刷新
        port:8080,
        hot:true
    },

    pulgins:[
        new HtmlWebpackPlugin({
            template:'./index.html',
            filenname:'index.html',
            tilte:'哈哈'
        }) 
    ]
}