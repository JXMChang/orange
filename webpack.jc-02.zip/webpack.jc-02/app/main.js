const greeter = requrie("./Greeter.js");
document.querySelector("#root").appendChild(greeter());